"""図を描くときの共通の処理(日本語フォント・海岸線)。"""
import io
import json
from functools import lru_cache
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402

COAST_PATH = Path(__file__).with_name("coastline_eastasia.json")  # Natural Earth 1:50m 海岸線(東アジアを切り出し)


def use_font(font_path: str | Path | None) -> None:
    """日本語フォント(BIZ UDゴシック)を使う。無ければ既定のフォントのまま。"""
    if not font_path:
        return
    try:
        font_manager.fontManager.addfont(str(font_path))
        name = font_manager.FontProperties(fname=str(font_path)).get_name()
        plt.rcParams["font.family"] = name
    except (OSError, RuntimeError, ValueError):
        pass


@lru_cache(maxsize=1)
def coastlines() -> list:
    try:
        return json.loads(COAST_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def draw_coast(ax, color="#555555", lw=0.6) -> None:
    for line in coastlines():
        xs, ys = zip(*line)
        ax.plot(xs, ys, color=color, lw=lw, zorder=1)


def to_png(fig, dpi=110) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return buf.getvalue()
