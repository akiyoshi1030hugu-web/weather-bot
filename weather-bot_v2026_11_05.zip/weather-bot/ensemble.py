"""アンサンブル予報(NOAA/NCEP の GEFS、31メンバー、0.5度)。

- NOMADS の grib filter で、必要な要素・範囲(東経100〜180度、北緯0〜60度)だけを取り出して取得する
  (1回あたり数十〜百数十KB。31メンバー×予報時間の数だけ、1秒以上の間隔をあけて取る)。
- 作る図
  1. 500hPa 高度のスパゲッティ図(5820m・5880m の等高線を全メンバー重ねる)
  2. 地点のプルーム図(850hPa 気温・海面気圧・6時間降水量の全メンバー)
  3. 台風のアンサンブル進路(各メンバーの海面気圧の極小を6時間ごとにたどった経路)
"""
import asyncio
import math
import os
from datetime import datetime, timedelta, timezone

import aiohttp
import numpy as np

NOMADS = "https://nomads.ncep.noaa.gov/cgi-bin/filter_gefs_atmos_0p50a.pl"
PAGE_URL = "https://www.nco.ncep.noaa.gov/pmb/products/gens/"
MEMBERS = ["gec00"] + [f"gep{i:02d}" for i in range(1, 31)]
REGION = (100, 180, 0, 60)          # 西, 東, 南, 北
MAX_HOURS = int(os.getenv("ENS_MAX_HOURS", "240"))
STEP_HOURS = int(os.getenv("ENS_STEP_HOURS", "6"))
READY_HOURS = float(os.getenv("ENS_READY_HOURS", "6"))     # 初期時刻からこの時間たったら取りに行く
CYCLES = [int(c) for c in os.getenv("ENS_CYCLES", "0").split(",") if c.strip()]
REQUEST_GAP = float(os.getenv("ENS_REQUEST_GAP", "1.0"))  # NOMADS への連続アクセスの間隔(秒)
SPAGHETTI_HOURS = (0, 24, 48, 72, 96, 120, 144, 168)
SPAGHETTI_LEVELS = (5820, 5880)
ENABLED = os.getenv("ENS_ENABLED", "1") == "1"
JST = timezone(timedelta(hours=9))


def parse_points(text: str) -> list[tuple[str, float, float]]:
    out = []
    for item in text.split(","):
        parts = item.split(":")
        if len(parts) == 3:
            out.append((parts[0].strip(), float(parts[1]), float(parts[2])))
    return out


POINTS = parse_points(os.getenv("ENS_POINTS", "高知:33.57:133.55,大分:33.24:131.62"))


def url(init: datetime, member: str, step: int) -> str:
    w, e, s, n = REGION
    return (f"{NOMADS}?dir=%2Fgefs.{init:%Y%m%d}%2F{init:%H}%2Fatmos%2Fpgrb2ap5"
            f"&file={member}.t{init:%H}z.pgrb2a.0p50.f{step:03d}"
            "&var_HGT=on&var_TMP=on&var_PRMSL=on&var_APCP=on"
            "&lev_500_mb=on&lev_850_mb=on&lev_mean_sea_level=on&lev_surface=on"
            f"&subregion=&leftlon={w}&rightlon={e}&toplat={n}&bottomlat={s}")


def latest_init(now: datetime) -> datetime:
    """いま取りに行ってよい、いちばん新しい初期時刻。"""
    now = now.astimezone(timezone.utc)
    t = now.replace(minute=0, second=0, microsecond=0)
    for _ in range(48):
        if t.hour in CYCLES and now - t >= timedelta(hours=READY_HOURS):
            return t
        t -= timedelta(hours=1)
    return t


# ---------- GRIB2 の読み取り ----------
def split_messages(data: bytes) -> list[bytes]:
    out, i = [], 0
    while True:
        i = data.find(b"GRIB", i)
        if i < 0 or i + 16 > len(data):
            return out
        edition = data[i + 7]
        n = int.from_bytes(data[i + 8:i + 16], "big") if edition == 2 else int.from_bytes(data[i + 4:i + 7], "big")
        if n <= 0:
            return out
        out.append(data[i:i + n])
        i += n


def decode(data: bytes) -> list[dict]:
    import eccodes
    fields = []
    for msg in split_messages(data):
        h = eccodes.codes_new_from_message(msg)
        try:
            g = lambda k: eccodes.codes_get(h, k)  # noqa: E731
            ni, nj = g("Ni"), g("Nj")
            lat1, lat2 = g("latitudeOfFirstGridPointInDegrees"), g("latitudeOfLastGridPointInDegrees")
            lon1, lon2 = g("longitudeOfFirstGridPointInDegrees"), g("longitudeOfLastGridPointInDegrees")
            vals = eccodes.codes_get_values(h).reshape(nj, ni)
            try:
                start, end = int(g("startStep")), int(g("endStep"))
            except Exception:
                start = end = int(g("step"))
            fields.append({"name": g("shortName"), "level": int(g("level")), "type": g("typeOfLevel"),
                           "start": start, "end": end, "values": vals.astype("float32"),
                           "lats": np.linspace(lat1, lat2, nj), "lons": np.linspace(lon1, lon2, ni)})
        finally:
            eccodes.codes_release(h)
    return fields


def pick(fields, name, type_=None, level=None):
    for f in fields:
        if f["name"] == name and (type_ is None or f["type"] == type_) and (level is None or f["level"] == level):
            return f
    return None


# ---------- 台風の簡易追跡 ----------
def find_low(f: dict, lat: float, lon: float, radius: float = 3.5) -> tuple[float, float, float] | None:
    """(lat, lon) の近くの海面気圧の極小 (緯度, 経度, hPa)。くぼみが浅ければ None。"""
    lats, lons, v = f["lats"], f["lons"], f["values"]
    yy, xx = np.meshgrid(lats, lons, indexing="ij")
    d = np.hypot(yy - lat, (xx - lon) * math.cos(math.radians(lat)))
    near = d <= radius
    if not near.any():
        return None
    vv = np.where(near, v, np.inf)
    j, i = np.unravel_index(np.argmin(vv), v.shape)
    if j in (0, v.shape[0] - 1) or i in (0, v.shape[1] - 1):
        return None
    ring = (np.hypot(yy - lats[j], (xx - lons[i]) * math.cos(math.radians(lats[j]))) <= 4.0)
    depth = float(np.mean(v[ring]) - v[j, i]) / 100
    if depth < 1.5:
        return None
    return float(lats[j]), float(lons[i]), float(v[j, i]) / 100


class Tracker:
    def __init__(self, start: tuple[float, float]):
        self.points = [start]
        self.alive = True
        self.started = False

    def update(self, f: dict) -> None:
        if not self.alive:
            return
        lat, lon = self.points[-1]
        if len(self.points) >= 2:                       # 直前の動きの分だけ先を探す
            lat += self.points[-1][0] - self.points[-2][0]
            lon += self.points[-1][1] - self.points[-2][1]
        low = find_low(f, lat, lon)
        if low is None:
            self.alive = False
            if not self.started:                        # 初期時刻に極小が無ければ経路にしない
                self.points = []
            return
        if not self.started:                            # 初期時刻:気象庁の位置の近くの極小から始める
            self.points = [(low[0], low[1])]
            self.started = True
        else:
            self.points.append((low[0], low[1]))


# ---------- 取得 ----------
class GefsRun:
    def __init__(self, session: aiohttp.ClientSession, init: datetime,
                 tcs: dict[str, tuple[float, float]] | None = None) -> None:
        self.session = session
        self.init = init
        self.steps = list(range(0, MAX_HOURS + 1, STEP_HOURS))
        self.tcs = tcs or {}
        self.z500: dict[int, list] = {s: [] for s in SPAGHETTI_HOURS if s <= MAX_HOURS}
        self.grid = None
        self.series = {name: {"t850": [], "mslp": [], "rain": []} for name, _, _ in POINTS}
        self.tracks: dict[str, list] = {tc: [] for tc in self.tcs}
        self.requests = 0

    async def get(self, member: str, step: int) -> bytes | None:
        for attempt in range(3):
            await asyncio.sleep(REQUEST_GAP)
            self.requests += 1
            try:
                async with self.session.get(url(self.init, member, step),
                                            timeout=aiohttp.ClientTimeout(total=120)) as r:
                    data = await r.read()
                    if r.status == 200 and data[:4] == b"GRIB":
                        return data
                    if r.status in (404,) or (r.status == 200 and data[:4] != b"GRIB"):
                        return None
            except (aiohttp.ClientError, asyncio.TimeoutError):
                pass
            await asyncio.sleep(10 * (attempt + 1))
        return None

    async def ready(self) -> bool:
        """最後のメンバーの最後の予報時間まで公開されているか。"""
        return await self.get(MEMBERS[-1], self.steps[-1]) is not None

    async def run(self, progress=None) -> None:
        for mi, member in enumerate(MEMBERS):
            trackers = {tc: Tracker(pos) for tc, pos in self.tcs.items()}
            series = {name: {"t850": [], "mslp": [], "rain": []} for name, _, _ in POINTS}
            for step in self.steps:
                data = await self.get(member, step)
                if data is None:
                    if mi == 0 and step == 0:
                        raise RuntimeError("GEFS のデータがまだ公開されていません")
                    break
                fields = await asyncio.to_thread(decode, data)
                self.add(fields, step, series, trackers)
            for name in series:
                for k in series[name]:
                    self.series[name][k].append(series[name][k])
            for tc, tr in trackers.items():
                self.tracks[tc].append(tr.points)
            if progress:
                await progress(f"GEFS {self.init:%m/%d %H}UTC:{mi + 1}/{len(MEMBERS)}メンバー")

    def add(self, fields, step, series, trackers) -> None:
        z = pick(fields, "gh", level=500)
        if z is not None and step in self.z500:
            self.grid = (z["lats"], z["lons"])
            self.z500[step].append(z["values"])
        t = pick(fields, "t", level=850)
        p = pick(fields, "prmsl") or pick(fields, "msl")
        r = pick(fields, "tp") or pick(fields, "apcp")
        for name, lat, lon in POINTS:
            if t is not None:
                series[name]["t850"].append((step, nearest(t, lat, lon) - 273.15))
            if p is not None:
                series[name]["mslp"].append((step, nearest(p, lat, lon) / 100))
            if r is not None:
                series[name]["rain"].append((r["start"], r["end"], nearest(r, lat, lon)))
        if p is not None:
            for tr in trackers.values():
                tr.update(p)


def nearest(f: dict, lat: float, lon: float) -> float:
    j = int(np.argmin(np.abs(f["lats"] - lat)))
    i = int(np.argmin(np.abs(f["lons"] - lon)))
    return float(f["values"][j, i])


def intervals(rain: list[tuple[int, int, float]]) -> list[tuple[int, float]]:
    """降水量(積算のしかたが「区間ごと」でも「初期時刻から」でも)を、6時間などの区間ごとの量にする。"""
    out, prev_end, prev_cum = [], 0, 0.0
    for start, end, v in sorted(rain, key=lambda x: x[1]):
        if end <= start:
            continue
        if start == 0 and prev_end > 0:              # 初期時刻からの積算
            amount, prev_cum = v - prev_cum, v
        else:
            amount = v
            prev_cum = v if start == 0 else prev_cum + v
        out.append((end, max(amount, 0.0)))
        prev_end = end
    return out


# ---------- 図 ----------
def valid_text(init: datetime, step: int) -> str:
    return (init + timedelta(hours=step)).astimezone(JST).strftime("%m/%d %H時")


def render_spaghetti(run: GefsRun, font_path=None) -> bytes:
    import matplotlib.pyplot as plt
    from charts import draw_coast, to_png, use_font
    use_font(font_path)
    steps = [s for s in run.z500 if run.z500[s]]
    lats, lons = run.grid
    rows = math.ceil(len(steps) / 4)
    fig, axes = plt.subplots(rows, 4, figsize=(18, 4.3 * rows), squeeze=False)
    colors = {5820: "#1f77b4", 5880: "#d62728"}
    for ax, step in zip(axes.flat, steps):
        draw_coast(ax)
        for k, field in enumerate(run.z500[step]):
            for lev in SPAGHETTI_LEVELS:
                ax.contour(lons, lats, field, levels=[lev], colors="black" if k == 0 else colors[lev],
                           linewidths=1.6 if k == 0 else 0.6, alpha=1 if k == 0 else 0.6)
        ax.set_xlim(105, 175)
        ax.set_ylim(10, 55)
        ax.set_aspect(1.2)
        ax.set_title(f"+{step}h  {valid_text(run.init, step)}(JST)", fontsize=10)
        ax.tick_params(labelsize=7)
        ax.grid(True, color="#dddddd", lw=0.4)
    for ax in list(axes.flat)[len(steps):]:
        ax.set_axis_off()
    fig.suptitle(f"GEFS 500hPa 高度 スパゲッティ図(青5820m・赤5880m、黒は control)"
                 f"  初期時刻 {run.init:%Y-%m-%d %H}UTC  {len(run.z500[steps[0]])}メンバー  出典:NOAA/NCEP",
                 fontsize=12)
    return to_png(fig, dpi=90)


def render_plume(run: GefsRun, name: str, font_path=None) -> bytes:
    import matplotlib.dates as mdates
    import matplotlib.pyplot as plt
    from charts import to_png, use_font
    use_font(font_path)
    s = run.series[name]
    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
    tt = lambda h: (run.init + timedelta(hours=h)).astimezone(JST).replace(tzinfo=None)  # noqa: E731
    for key, ax, unit in (("t850", axes[0], "850hPa 気温 (℃)"), ("mslp", axes[1], "海面気圧 (hPa)")):
        allv = []
        for k, mem in enumerate(s[key]):
            if not mem:
                continue
            x, y = zip(*mem)
            allv.append(dict(mem))
            ax.plot([tt(h) for h in x], y, color="black" if k == 0 else "#4a7fb5",
                    lw=1.8 if k == 0 else 0.6, alpha=1 if k == 0 else 0.55)
        steps = sorted({h for m in allv for h in m})
        mean = [np.mean([m[h] for m in allv if h in m]) for h in steps]
        ax.plot([tt(h) for h in steps], mean, color="#d62728", lw=1.6, label="平均")
        ax.set_ylabel(unit)
        ax.grid(True, color="#dddddd", lw=0.5)
        ax.legend(loc="upper right", fontsize=8)
    ax = axes[2]
    per = [intervals(m) for m in s["rain"] if m]
    ends = sorted({e for m in per for e, _ in m})
    data = [[dict(m).get(e, np.nan) for m in per] for e in ends]
    if ends:
        width = STEP_HOURS / 24 * 0.8
        pos = [mdates.date2num(tt(e - STEP_HOURS / 2)) for e in ends]
        ax.boxplot(data, positions=pos, widths=width, manage_ticks=False, showfliers=True,
                   flierprops={"markersize": 2})
        ax.plot([tt(e - STEP_HOURS / 2) for e in ends], [np.nanmean(d) for d in data], color="#d62728", lw=1.2,
                label="平均")
        ax.legend(loc="upper right", fontsize=8)
    ax.set_ylabel(f"{STEP_HOURS}時間降水量 (mm)")
    ax.set_ylim(bottom=0)
    ax.grid(True, color="#dddddd", lw=0.5)
    ax.xaxis.set_major_locator(mdates.DayLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m/%d"))
    ax.set_xlabel("日本時間")
    fig.suptitle(f"GEFS プルーム図 {name}  初期時刻 {run.init:%Y-%m-%d %H}UTC  "
                 f"{len(s['t850'])}メンバー(黒:control、赤:平均、箱:メンバーのばらつき)  出典:NOAA/NCEP", fontsize=11)
    return to_png(fig, dpi=90)
